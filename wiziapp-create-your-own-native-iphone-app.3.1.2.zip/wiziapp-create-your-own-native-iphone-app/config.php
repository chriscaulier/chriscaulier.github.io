<?php
	$wiziapp_plugin_config = array(
		'build_host' => 'http://prudmin.wiziapp.com'
	);
